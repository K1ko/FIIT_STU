#include <stdio.h>

int main()
{
    int pole[]={4,7,1,3,2,5,6};
    int pole1[]={},i,a;
    for(i=0;i<7;i++)
    {
        a = pole[i]%2;
        if(a==0){
            printf("%d",pole1[i]);
        }
    }
}